#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

int main() {
    Pilha pilha;
    criaPilha(&pilha);

    int opcao;
    Dado dado;

    do {
        printf("0. Fim\n");
        printf("1. Empilha\n");
        printf("2. Desempilha\n");
        printf("3. Quantidade de nodos\n");
        printf("4. Exibe situacao da lista\n");
        printf("5. Consulta topo\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 0:
                printf("Fim do programa.\n");
                break;
            case 1:
                printf("Informe o codigo e o peso: ");
                scanf("%d %f", &dado.cod, &dado.peso);
                if (empilha(&pilha, dado) == SUCESSO) {
                    printf("Empilhado com sucesso.\n");
                } else {
                    printf("Erro ao empilhar.\n");
                }
                exibe(pilha);
                break;
            case 2:
                if (desempilha(&pilha, &dado) == SUCESSO) {
                    printf("Desempilhado com sucesso. Codigo: %d, Peso: %.2f\n", dado.cod, dado.peso);
                } else {
                    printf("Erro ao desempilhar. Pilha vazia.\n");
                }
                exibe(pilha);
                break;
            case 3:
                printf("Quantidade de nodos na pilha: %d\n", estaVazia(pilha) ? 0 : 1);
                break;
            case 4:
                printf("Situacao da pilha:\n");
                exibe(pilha);
                break;
            case 5:
                if (consultaTopo(pilha, &dado) == SUCESSO) {
                    printf("Topo da pilha - Codigo: %d, Peso: %.2f\n", dado.cod, dado.peso);
                } else {
                    printf("Pilha vazia.\n");
                }
                break;
            default:
                printf("Opcao invalida.\n");
                break;
        }
    } while (opcao != 0);

    return 0;
}
