#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

void criaPilha(Pilha *p){
     p->topo = NULL;
}

void exibe(Pilha p) {
    Nodo *atual = p.topo;
    while (atual != NULL) {
        printf("Codigo: %d, Peso: %.2f\n", atual->info.cod, atual->info.peso);
        atual = atual->prox;
    }
}

int empilha(Pilha *p, Dado dado){
     Nodo *novoNodo = (Nodo *)malloc(sizeof(Nodo));
     if (novoNodo == NULL){
          return FALTOU_MEMORIA;
     } 

     novoNodo -> info = dado;
     novoNodo -> prox = p->topo;
     p->topo = novoNodo;
     return SUCESSO;
}

int desempilha(Pilha *p, Dado *dado) {
    if (estaVazia(*p)) {
        return PILHA_VAZIA;
    }
    Nodo *nodoRemovido = p->topo;
    *dado = nodoRemovido->info;
    p->topo = nodoRemovido->prox;
    free(nodoRemovido);
    return SUCESSO;
}

int estaVazia(Pilha p) {
    return p.topo == NULL;
}

int consultaTopo(Pilha p, Dado *dado) {
    if (estaVazia(p)) {
        return PILHA_VAZIA;
    }
    *dado = p.topo->info;
    return SUCESSO;
}









