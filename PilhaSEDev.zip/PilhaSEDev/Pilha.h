#ifndef PILHA_H
#define PILHA_H

#define SUCESSO 0 
#define PILHA_VAZIA 1
#define FALTOU_MEMORIA 2

typedef struct {
        int cod;
        float peso;
} Dado;

typedef struct nodo Nodo;

struct nodo {
        Dado info;
        Nodo *prox;
};

typedef struct {
        Nodo *topo;
} Pilha;

        

void criaPilha(Pilha *p);
int empilha(Pilha *p, Dado dado);
int desempilha(Pilha *p, Dado *dado);
int esta_vazia(Pilha p);
int consulta_topo(Pilha p, Dado *dado);
void exibe(Pilha p);

#endif
